

console.log("affiche moi qqch FDP");
function calculsum (tableau){
let somme=0;
for( i= 0; i< tableau.length; i++ ){

    somme += tableau[i];
}
return somme;
}

const nombres = [10, 5, 3, 8, 2];
const resultat = calculsum(nombres);
console.log(resultat);



function trouverNombreMax(tableau){
    let max =tableau[0];
    for( i= 0; i< tableau.length; i++ ){

if ( tableau[i]> max){
max = tableau[i];

}
    }
return max;
}

const entier = [10, 5, 3, 8, 2, 12];
const result = trouverNombreMax(entier);
console.log(result);

function compterOccurrences( tableau, element){
let compteur = 0

for( i= 0; i< tableau.length; i++ ){
    if ( tableau[i] === element){
        compteur++;
    
    }
        }
        return compteur;
}



const number = [1, 2, 3, 4, 3, 2, 1, 2, 3];
const occurences = compterOccurrences(number, 2);
console.log(occurences); // Affiche 3

// Exercice : Somme des nombres pairs

// Fonction pour calculer la somme des nombres pairs d'un tableau
function sommeNombresPairs(tableau) {
    let somme = 0;
  
    for (let i = 0; i < tableau.length; i++) {
      if (tableau[i] % 2 === 0) {
        somme += tableau[i];
      }
    }
  
    return somme;
  }
  
  // Exemple d'utilisation
//   const numbers = [2, 2, 3, 4, 5, 6, 7, 8, 9, 10];
//   const sommePairs = sommeNombresPairs(numbers);
//   console.log(sommePairs); // Affiche 30 (2 + 4 + 6 + 8 + 10)
  
//   const container = document.getElementById('container');
//   console.log(container);

//   const titre = container.getElementsByTagName('h1')[0];
//   console.log(titre.textContent);

//   const paragraphes = container.getElementsByTagName('p');
//   for (let i = 0; i < paragraphes.length; i++) {
//     console.log(paragraphes[i].textContent);
//   }

//   const listeItems = container.getElementsByTagName('li');
//   for (let i = 0; i < listeItems.length; i++) {
//     console.log(listeItems[i].textContent);
//   }

//   const listeItem = container.getElementsByTagName('li');
// for (let i = 0; i < listeItem.length; i++) {
//   const parentElement = listeItem[i].parentNode;
//   console.log(parentElement);
// }

const listeItem = document.querySelectorAll('li');
for (let i = 0; i < listeItem.length; i++) {
  const parentElement = listeItem[i].parentNode;
  console.log(parentElement);
}
const listeItems = document.querySelectorAll('ul');
const container = document.getElementById('container');

listeItems.forEach((item) => {
  const clone = item.cloneNode(true);
container.appendChild(clone);
});
