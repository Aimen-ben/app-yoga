const main =document.getElementById('main');
let exerciceArray =[
    { pic : 0, min : 1},
    { pic : 1, min : 1},
    { pic : 2, min : 1},
    { pic : 3, min : 1},
    { pic : 4, min : 1},
    { pic : 5, min : 1},
    { pic : 6, min : 1},
    { pic : 7, min : 1},
    { pic : 8, min : 1},
    { pic : 9, min : 1},
]

class exercice {
    constructor(pic, min)
}

const utils = {

}

const page = {
lobby : function(){
document.querySelector('h1').innerText = "Paramétrage "
main.innerHTML = 'p'
}

}


console.log("affiche moi qqch FDP");